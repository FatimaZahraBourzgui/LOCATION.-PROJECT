#include <stdio.h>
#include <stdlib.h>
typedef struct date{
	int annee;
	int mois;
	int jours;
}date;
typedef struct Voiture
{ 
 int idVoiture; 
 char marque[15]; 
 char nomVoiture[15]; 
 char couleur[7]; 
 int nbplaces; 
 int prixJour; 
 char EnLocation[4]; 
} voiture;
 
typedef struct contratLocation
{ 
 float numContrat; 
 int idVoiture; 
 int idClient; 
 date debut; 
 date fin; 
 int cout; 
} contrat; 
typedef struct Client
{ 
 int idClient; 
 char nom[20]; 
 char prenom[20]; 
 int cin; 
 char adresse[15]; 
 int telephone; 
}client;

void liste_des_voitures(){
	
	FILE *fichier=NULL;
fichier=fopen("voitures.txt","");

}
 
 void ajouter_des_voitures(){
 voiture ajouter;
 FILE *fichier;
 printf("veuillez ecrire les informations du voiture \n");
 scanf("%d \n %s \n %s \n %s\n %d \n %d \n %s \n",ajouter.idVoiture,ajouter.nomVoiture,ajouter.marque,ajouter.couleur,ajouter.nbplaces,ajouter.prixJour,ajouter.EnLocation);
 fichier=fopen("voitures.txt","w");
 fprintf(fichier,"idvoiture=%d \n nom=%s \n marque=%s \n couleur=%s \n nbrplaces=%d \n prixJour=%d \n enlocation=%s",ajouter.idVoiture,ajouter.nomVoiture,ajouter.marque,ajouter.couleur,ajouter.nbplaces,ajouter.prixJour,ajouter.EnLocation);
	
}
void modifier_voiture(){
	
	
}
void supprimer_voiture(){
	
}
void retour_aumenuprincipal(){

}


 
void (*GV[5])(void)={liste_des_voitures,ajouter_des_voitures,modifier_voiture,supprimer_voiture,retour_aumenuprincipal};
void gestionvoiture(void){
//	voiture gestiondevoiture;

		int n,i;
		
FILE *fichier=NULL;
fichier=fopen("voitures.txt","a");



   printf("\n \n \n");
do{
	printf("\t \t gestion de voiture");
   printf("\n \n \n _______________________________________\n \n \n");
   printf(" \t liste des voitures--------1");
   printf("\n \t ajouter voiture--------2");
   printf("\n \t modifier voiture-------3");
   printf("\n \t supprimer voture-------4");
   printf(" \n  \t retour---------------------5");
   printf("\n \n \n_______________________________________");
   printf("\n \n \n votre choix: \n");
   scanf("%d",&n);
	
}while(n<0||n>5);
for(i=0;i<n;i++)
GV[i]();

}
 
void location(void){
		int n;
	printf("\n \n \n");
	do{
	printf("\t \t location d'une voiture'");
   printf("\n \n \n _______________________________________\n \n \n");
   printf(" \t visualiser contrat---------------1");
   printf("\n \t louer voiture------------------2");
   printf("\n \t retourner voiture------------- 3");
   printf("\n \t modifier contrat---------------4");
   printf(" \n  \t supprimer contrat------------5");
   printf(" \n  \t retour-----------------------6");

   printf("\n \n \n_______________________________________");
   printf("\n \n \n votre choix: \n");
   scanf("%d",&n);
	
}while(n<0||n>6);
}

void gestionclient(void){


}
void (*tableau_des_fcts[4])(void)={location,gestionvoiture,gestionclient};

void (*menuprincipal())(void){

	int a,i;
	printf("\n \n \n ");
do{	printf(" \t  \t Menu Principal");
  printf(" \n  \n \n  \t acceder au menu: \n \n \n");
  printf("__________________________________________");

       printf("\n \n \t Location ...............1"),
        printf("\n \t Gestion voitures .........2"),
        printf("\n  \t Gestion clients...........3"),
        printf("\n  \t Quitter...................4"),
  printf("\n \n___________________________________________"),
        printf("\n \n \n \n \t votre choix  :"),
        scanf("%d",&a);}while(a<0||a>4);
        for(i=0;i<=a;i++)
        tableau_des_fcts[i+1];}
    
    
main(){
		
	menuprincipal();
	gestionvoiture();
    location();
}
	
	
  
